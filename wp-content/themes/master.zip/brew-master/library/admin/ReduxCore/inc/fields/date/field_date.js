/*global jQuery*/

jQuery(document).ready(function () {
	jQuery('.redux-datepicker').each(function(){
		jQuery(this).datepicker();
	});
});